#!/usr/bin/env bash
wget -qO- https://github.com/djay/covidthailand/releases/download/1/datasets.tar.gz | tar xz
wget -qO- https://github.com/djay/covidthailand/releases/download/1/inputs.tar.gz | tar xz
